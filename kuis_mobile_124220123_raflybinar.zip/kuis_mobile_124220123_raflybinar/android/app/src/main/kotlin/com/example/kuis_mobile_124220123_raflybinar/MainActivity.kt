package com.example.kuis_mobile_124220123_raflybinar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
