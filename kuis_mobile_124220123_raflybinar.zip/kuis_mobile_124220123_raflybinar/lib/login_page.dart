import 'package:flutter/material.dart';
import 'package:kuis_mobile_124220123_raflybinar/dummy/home_page.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isPasswordVisible = false; 

  void _login() {
    if (_usernameController.text.isNotEmpty &&
        _passwordController.text == "pass") {
      _showSuccessDialog();
    } else {
      _showFailureSnackBar();
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color.fromARGB(255, 151, 254, 73),
          title: Text(
            "Yeayy udah login nih",
            style: TextStyle(color: const Color.fromARGB(255, 42, 42, 42)),
          ),
          content: Text(
            "HAI, ${_usernameController.text}!",
            style: TextStyle(color: const Color.fromARGB(255, 3, 3, 3)),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); 
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        HomePage(username: _usernameController.text),
                  ),
                );
              },
              child: Text(
                'Next',
                style: TextStyle(color: const Color.fromARGB(255, 43, 43, 43)),
              ),
            ),
          ],
        );
      },
    );
  }

  void _showFailureSnackBar() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Username atau password salah."),
        backgroundColor: const Color.fromARGB(255, 218, 26, 8),
        action: SnackBarAction(
          label: 'Coba Lagi',
          onPressed: () {
            _usernameController.clear();
            _passwordController.clear();
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 56, 250, 38),
        elevation: 0,
      ),
      body: Container(
        color: const Color.fromARGB(255, 56, 250, 38),
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'BELA NEGARA',
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 8, 8, 8),
                shadows: [
                  Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.black38,
                  ),
                ],
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Image.asset('images/logo_upn.png'),
              ],
            ),
            SizedBox(height: 30),
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                labelText: 'Username',
                labelStyle:
                    TextStyle(color: const Color.fromARGB(255, 145, 145, 145)),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.20),
                  borderSide: BorderSide(
                    color: Colors.black, 
                    width: 1.0, 
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: const Color.fromARGB(255, 0, 255, 68),
                    width: 1.0, 
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: const Color.fromARGB(255, 0, 255, 68),
                    width: 1.0,
                  ),
                ),
                prefixIcon: Icon(Icons.person, color: const Color.fromARGB(255, 82, 102, 100)),
              ),
            ),
            SizedBox(height: 25),
            TextField(
              controller: _passwordController,
              obscureText: !_isPasswordVisible,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                labelText: 'Password',
                labelStyle:
                    TextStyle(color: const Color.fromARGB(255, 82, 102, 100)),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: Colors.black, 
                    width: 1.0, // Mengubah lebar border
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: const Color.fromARGB(255, 0, 255, 68), 
                    width: 1.0, // Mengubah lebar border
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide(
                    color: const Color.fromARGB(255, 0, 255, 68), 
                    width: 1.0, // Mengubah lebar border
                  ),
                ),
                prefixIcon: Icon(Icons.lock, color: const Color.fromARGB(255, 82, 102, 100)),
                suffixIcon: GestureDetector(
                  onTap: () {
                    setState(() {
                      _isPasswordVisible = !_isPasswordVisible;
                    });
                  },
                  child: Icon(
                    _isPasswordVisible
                        ? Icons.visibility
                        : Icons.visibility_off,
                    color: const Color.fromARGB(255, 82, 102, 100),
                  ),
                ),
              ),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: _login,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 51, 116, 111),
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
              ),
              child: Text(
                'Login',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
