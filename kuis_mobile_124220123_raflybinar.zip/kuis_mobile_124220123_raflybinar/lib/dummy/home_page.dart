import 'package:flutter/material.dart';
import 'dummy_faculty.dart'; 

class HomePage extends StatelessWidget {
  final String username;

  HomePage({required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Halo, $username'),
        backgroundColor: const Color.fromARGB(255, 56, 250, 38),
      ),
      body: Column(
        children: [
          // Card untuk UPN Veteran Yogyakarta di bawah AppBar
          GestureDetector(
            onTap: () {
              // Navigasi ke halaman detail UPN ketika card di-tap
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailUpnPage(), // Gantilah dengan halaman detail yang sesuai.
                ),
              );
            },
            child: Card(
              color: const Color.fromARGB(255, 56, 250, 38),
              margin: const EdgeInsets.all(10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(0.0), // Menjadi persegi panjang dengan sudut tajam
                side: const BorderSide(color: Colors.black), // Border yang sama dengan Container
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start, // Agar teks rata kiri
                  children: const [
                    Text(
                      'Sudahkan kamu mengenal UPN Jogja?',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8), // Jarak antara teks
                    Text(
                      'UPN Jogja adalah kampus favorit di DIY lho!',
                      style: TextStyle(fontSize: 15),
                    ),
                    SizedBox(height: 8), // Jarak antara teks
                    Text(
                      'Kenalan lebih jauh yuk!',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            // Menggunakan ListView untuk menampilkan list fakultas
            child: ListView.builder(
              itemCount: facultyList.length,
              itemBuilder: (context, index) {
                final faculty = facultyList[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  color: const Color.fromARGB(255, 255, 247, 0), // Menetapkan warna latar belakang Card
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(0.0), // Sudut persegi panjang
                    side: const BorderSide(color: Colors.black), // Sama dengan Card hijau
                  ),
                  child: ListTile(
                    leading: Image.asset(faculty.imageAsset, width: 50, height: 50),
                    title: Text(faculty.name),
                    subtitle: Text('Jumlah Program Studi: ${faculty.numberOfMajors}'),
                    trailing: Text('Jumlah Mahasiswa: ${faculty.numberOfStudents}'),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class DetailUpnPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail UPN Yogyakarta'),
        backgroundColor: const Color.fromARGB(255, 56, 250, 38),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.asset('images/upn.jpg', height: 200),
            ),
            _buildSection(
              'Pendidikan UPN',
              'Arah Pendidikan',
              'Arah pendidikan UPN ”Veteran” Yogyakarta adalah mengembangkan ilmu pengetahuan dan teknologi yang dilandasi oleh nilai-nilai kedisiplinan, kejuangan, kreativitas, keunggulan, kebangsaan, dan kejujuran dalam rangka menunjang pembangunan nasional melalui bidang pendidikan tinggi dalam rangka terciptanya sumber daya manusia yang unggul di era global dengan dilandasi jiwa bela negara.',
              'Tujuan Pendidikan',
              [
                'Menyelenggarakan pendidikan dan pengajaran yang berkualitas guna menghasilkan lulusan berdaya saing global yang memiliki jiwa disiplin, berdaya juang, kreatif, serta berwawasan kebangsaan dan mampu menjadi komponen pendukung dalam sistem pertahanan negara.',
                'Meningkatkan kuantitas dan kualitas penelitian guna menunjang pengembangan mutu pendidikan dan pengajaran, mengembangkan dan menerapkan ilmu pengetahuan dan teknologi (IPTEK) untuk menunjang pengabdian kepada masyarakat, serta menghasilkan modal intelektual dan karya ilmiah dalam rangka menunjang pembangunan nasional.',
                'Mengembangkan kegiatan pengabdian kepada masyarakat melalui penyediaan layanan ilmu pengetahuan dan teknologi (IPTEK) dalam rangka meningkatkan kesejahteraan masyarakat, peningkatan keberdayaan masyarakat, dan peningkatan reputasi UPN ”Veteran” Yogyakarta.',
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, String subtitle, String content, String sectionTitle, List<String> listItems) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle(title),
        const SizedBox(height: 8),
        _buildSectionSubtitle(subtitle),
        const SizedBox(height: 8),
        _buildTextContent(content),
        const SizedBox(height: 16),
        _buildSectionSubtitle(sectionTitle),
        for (var item in listItems)
          _buildTextContent(item),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: Color.fromARGB(255, 0, 0, 0),
      ),
    );  
  }

  Widget _buildSectionSubtitle(String subtitle) {
    return Text(
      subtitle,
      style: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Color.fromARGB(255, 0, 0, 0),
      ),
    );
  }

  Widget _buildTextContent(String content) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        content,
        style: const TextStyle(fontSize: 16, height: 1.5),
      ),
    );
  }
}
