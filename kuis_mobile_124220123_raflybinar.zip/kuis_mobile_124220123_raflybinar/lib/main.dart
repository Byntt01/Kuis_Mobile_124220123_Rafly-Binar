import 'package:flutter/material.dart';
import 'package:kuis_mobile_124220123_raflybinar/login_page.dart';

void main() {
  runApp(facultyApp());
}


class facultyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'List Fakultas UPNYK',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: LoginPage(),
    );
  }
}
